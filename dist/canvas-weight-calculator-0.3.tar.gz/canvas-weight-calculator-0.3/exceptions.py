class SettingsException(Exception):
    pass


class RangeFileNotFound(Exception):
    pass


class RangeValidationException(Exception):
    pass
